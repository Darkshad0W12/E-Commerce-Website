<?php
  $msg = "";
session_start();  // If upload button is clicked ...
 //$uname= $_SESSION["uname"];
 //$upload =$_POST['upload'];
 $upload = (isset($_POST['model'])?$_POST['model']:"no");
 if($upload != "no")	{
	 
	 $brand=$_POST['brand'];
	 $model=$_POST['model'];
	 $price=$_POST['price'];
	 $type=$_POST['type'];
	 $details=$_POST['details'];
	 $storage=$_POST['storage'];
 
    $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];   
        
		mkdir("../phone/$model",777,true);
		$folder = "../phone/$model/".$filename;
		$folder1 = "C:/xampp/htdocs/dashboard/somnath/database/shoping";
		copy('product/index.php',"../phone/$model/index.php");
		copy('product/logo.png',"../phone/$model/logo.png");
         require_once'conn.php';
		// $pic="phone/".$model."/".$filename;
  
        // Get all the submitted data from the form
		$quantity=20;
        $sql = "INSERT INTO `mobile`(`brand`, `model`, `price`, `details`, `pic`, `storage`,`type`, `quantity`) VALUES ('$brand','$model','$price','$details','$filename','$storage','$type','$quantity')";
        // Execute query
        mysqli_query($conn, $sql);
         
        // Now let's move the uploaded image into the folder: image
        if (move_uploaded_file($tempname, $folder))  {
				copy("../phone/$model/".$filename,"../".$filename);
            $msg = "Image uploaded successfully";
			 $_POST['upload'] ="null";
			 header("location:add_product0.php");
        }else{
            $msg = "Failed to upload image";
      }
 }
           require_once'conn.php';
  
  $result = mysqli_query($conn, "SELECT * FROM image");
  while($data = mysqli_fetch_array($result)){
	  $name =$data['filename'];
  }
  

 
      ?>
	  
	  <img width='20%' src="image/<?php echo $name ?> ">



 
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="add_product.css">

<title>Add New Product</title>
<body>
<!--img src="logo1.jpeg" width="10%"-->

 
 <center> <form method="POST" action="add_product.php" enctype="multipart/form-data">
  <h1>Add Product </h1>
  <table cellspacing="15">
  <tr>
  
 <th> <label> Product Brand :</label><input type="text" name="brand" required><th> <label>Model :</label><input type="text" name="model" required>
  
 <th><label> Type :</label><select name="type">
  <option >Product type
 <option value="phone" >Mobile
 <option value="laptop">Laptop
 <option value="tv" >Television
 </select>
 <tr>
 <th><label>Price :</label> <input type="number" name="price" required> <th><label>Details : </label><input type="text" name="details">
 <th><label>Storage : </label> <input type="text" name="storage" required><br>
 
    <tr>
<th>	<label>Picture :</label> <input type="file" name="uploadfile" value=""/>
       
      <div>
         <th colspan="2"> <button type="submit" name="upload">UPLOAD</button>
        </div>
		</table>
  </form>
</div>
</body>
</html>
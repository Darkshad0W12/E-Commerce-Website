<html>
	<head> <link rel="stylesheet" href="admin.css">
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		  <link rel="stylesheet" href="login.css">
		  <link rel="stylesheet" href="all_product.css">
		 <link rel = "icon" href = "logo.png" type = "image/x-icon">
		<link rel="stylesheet" href="slide.css">
   		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
   		 <script src="admin.js"></script>
   		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script type="text/javascript">
var timestamp = '<?=time();?>';
function updateTime(){
  $('#time').html(Date(timestamp));
  timestamp++;
}
$(function(){
  setInterval(updateTime, 1000);
});
</script>
	</head>
	<body>
	
<?php
session_start();
?>

<center><h1>DigiCart</h1></center>

<!--<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Login</button>-->

<div id="header">
<span id="opener" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
<p id="time"></p>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="#">Clients</a>
  <a href="#">Orders</a>
    <a href="#">Quaries</a>
</div>
</div>

	
<?php
			require_once('conn.php');
			$order = (isset($_GET["order"])?$_GET["order"]:"");
			//echo "$order";
			if($order == "asc"){
			$sql = "SELECT * FROM mobile ORDER BY price ASC";
			}
			else if($order="dsc"){
				$sql = "SELECT * FROM mobile ORDER BY price DESC";
			}
			else if($order="brand"){
				$sql = "SELECT * FROM mobile ORDER BY brand";
			}
			
			else{
				$sql = "SELECT * FROM mobile";
				
			}
			//echo "connected";
			
			$result= $conn->query($sql);
			if($result->num_rows>0){
				
				?>
				<div id = "contanar">
<center>
<div id ="filter"class="dropdown">
  <button class="dropbtn"><i class="fas fa-filter"></i></button>
  <div class="dropdown-content">
  <a href="all_product.php?order=asc">Price Low to High</a>
  <a href="all_product.php?order=dsc">Price High to Low</a>
  <a href="all_product.php?order=brand">Order by brand</a>
  </div>
</div>


<table id="customers">
		<tr>
		<th>Serial
		<th>Product Brand
		<th>Model
		<th>Quantity
		<th>price
		<th>Type
		<th colspan="2">Action &nbsp &nbsp
		</tr>
				
				
				
				<?php
				
					while($row = $result->fetch_assoc()) {
						$serial = '$row["serial"]';
						?>
						<tr>
								<td><?php echo $row["serial"]; ?></td>
								<td><?php echo $row["brand"]; ?></td>
								<td><?php echo $row["model"]; ?></td>
								<td><?php echo $row["quantity"]; ?></td>
								<td><?php echo $row["price"]; ?></td>
								<td><?php echo $row["type"]; ?></td>
								<td><?php echo"<a href='remove.php?serial=$row[serial]'>" ?><button  type="button">delete</button></a></td>
								
						</tr>
						
						
						
						<?php
						  }
						}
	else{ echo"<center>"."<h2>"." The product you are looking for is not available right now"."</h2>"."</center";
		}
$conn->close();
		?>
		
		</table>
</div>


</body>
</html>

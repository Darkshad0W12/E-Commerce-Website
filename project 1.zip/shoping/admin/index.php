<html>
	<head> <link rel="stylesheet" href="admin.css">
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		  <link rel="stylesheet" href="login.css">
		  <link rel="stylesheet" href="index.css">
		 <link rel = "icon" href = "logo.png" type = "image/x-icon">
		<link rel="stylesheet" href="slide.css">
   		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
		 <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
   		 <script src="admin.js"></script>
   		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script type="text/javascript">
var timestamp = '<?=time();?>';
function updateTime(){
  $('#time').html(Date(timestamp));
  timestamp++;
}
$(function(){
  setInterval(updateTime, 1000);
});
</script>
<script>
function goto(location){
	// alert(document.cookie);
	window.location.href=location;	
}
</script>
	</head>
	
<?php
session_start();
if(isset($_SESSION["admin"])){
	echo"<body>";
}
else{
	
	echo "<body onload=document.getElementById('id01').style.display='block'>";

}
?>
<center><h1>DigiCart</h1></center>

<!--<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Login</button>-->

<div id="id01" class="modal">
  
  <form class="modal-content animate" action="login.php " method="post">
    <div class="imgcontainer">
      <!--span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span-->
      <img src="logo.jpeg" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label for="uname" name="username"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="username" required>

      <label for="psw" name="passwoard"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="passwoard" required>
        
      <button type="submit">Login</button>
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <!--button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button-->
      <span class="psw">Forgot <a href="#">password?</a></span>
    </div>
  </form>
</div>
<div id="contanar">
<span id="opener" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
<p id="time"></p>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="all_product.php">All Products</a>
  <a href="user.php">Clients</a>
  <a href="orders.php">Orders</a>
   <a href="insert.html">Add User</a>
   <a href="add_product0.php">Add Products</a>
   <a href="quaries.php">Quaries</a>
   <a href="logout.php">logout</a>
</div>
</div>


<div class="deta" id="piechart"><h2>Working.... for Digicart statistic</h2></div>
<script type="text/javascript">
// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

// Draw the chart and set the chart values
function drawChart() {
  var data = google.visualization.arrayToDataTable([
  ['Task', 'Hours per Day'],
  ['Orders', 8],
  ['Cancled', 2],
  ['deleverd', 4],
  ['breach', 4],
  ['quary', 4],
  ['new user', 2],
  ['Lost User', 8]
]);

  // Optional; add a title and set the width and height of the chart
  var options = {'title':'Todays Work Flow', 'width':550, 'height':400};

  // Display the chart inside the <div> element with id="piechart"
  var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  chart.draw(data, options);
}
</script>



<div id="rating" class="deta" >
<?php
			require_once('conn.php');
			$sql  ="SELECT * FROM quary";
			//echo "connected";
			
			$result= $conn->query($sql);
			if($result->num_rows>0){
				
				?>
				<div id = "contanar">
<center>
<h2>Quaries</h2>

<table id="customers" border="1" style="border-collapse:collapse;" onclick="goto('quaries.php')">
		<tr>
		<th>Serial
		<th>UserName
		<th>Problem
		<th>Answer
		</tr>
				
				
				
				<?php
				
					while($row = $result->fetch_assoc()) {
						$serial = '$row["serial"]';
						?>
						<tr>
								<td><?php echo $row["serial"]; ?></td>
								<td><?php echo $row["username"]; ?></td>
								<td><?php echo $row["problem"]; ?></td>
								<td id="answer"><?php echo $row["answer"];?></td>
								
								</form>
						</tr>
						
						
						
						<?php
						  }
						}
	else{ echo"<center>"."<h2>"." The product you are looking for is not available right now"."</h2>"."</center";
		}
$conn->close();
		?>
		
		</table>
</div>



</div>

</body>
</html>
</html>

 <html>
	<head>
		<title> store your data</title>
	</head>
	<body>
		<?php
			$servername = "localhost";
			$username="root";
			$passwoard ="";
			$dbname= "reg";
	$conn = mysqli_connect($servername ,$username,$passwoard,$dbname);
	if(!$conn){die("connection failed :".mysquli_conect_error());
		}
	//echo "connected";
	$name=$phone=$email=$address=$uname=$passwoard="";
	$name=$_POST["name"];
	$uname=$_POST['uname'];
	$passwoard=$_POST['passwoard'];
	$phone=$_POST["phone"];
	$email=$_POST["email"];
	$address=$_POST['address'];
       $chku="SELECT * FROM data WHERE username='$uname' ";
			$result= $conn->query($chku);
		if($result->num_rows>0){echo"<script> alert('username Already registerd please choos another one');
	window.location.href='insert.html';	</script>";	
						
					}


		else{
			$chke="SELECT * FROM data WHERE email='$email' ";
			$result= $conn->query($chke);
			if($result->num_rows>0){
					echo"<script> alert('Email already registerd');
	window.location.href='insert.html';	</script>";	
						}


			else{
			$sql="INSERT INTO data (name,username,passwoard,phone,email,address)
			 VALUES('$name','$uname','$passwoard','$phone','$email','$address')";
			if($conn->query($sql)===TRUE){
			echo"<script> alert('Account Creation Success');
	window.location.href='index.php';	</script>";	}
			else{echo "error".$sql."<br>".$conn->error;}
			$conn->close();
				}
			}

		?>

	</body>
</html>

<html>
	<head><title>login</title>
	</head>
	<body bgcolor="lightblue">
<?php
session_start();
?>
		<?php 
			$servername="localhost";
			$username = "root";
			$passwoard ="";
			$dbname="reg";
			$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			//echo "connected";
			$username=$passwoard="";
			$username=$_POST["username"];
			$passwoard=$_POST["passwoard"];
			$sql="SELECT * FROM data WHERE username = '$username' AND passwoard = '$passwoard' ";
			$result= $conn->query($sql);
			if($result->num_rows>0){
				
					while($row = $result->fetch_assoc()) {
	$_SESSION["user"] = $row["name"];
	$_SESSION["admin"] = $row["serial"];
	// $_SESSION["email"] = $row["email"];
	// $_SESSION["address"] = $row["address"];
	
	
        // $_SESSION["uname"] = $row["username"];
	$_SESSION["phone"] = $row["phone"];
    echo "<h3>". "Hello  " . $row["name"]."<br>"."Phone : " .$row["phone"]."<br>"."Email : " . $row["email"]. "<br></h3>";
					}
		header("Location:index.php");							  
			}			
	else{ echo "<script> alert('wrong Credentials');
	window.location.href ='index.php';</script>";
			
	//"Wrong username or password"."<br>"."<a href='f_password.html'>". "Forget passwoard "."</a>";
	
		}






$conn->close();
		?>

	</body>
</html>
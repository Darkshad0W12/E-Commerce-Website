<html>
	<head> <link rel="stylesheet" href="admin.css">
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		  <link rel="stylesheet" href="login.css">
		  <link rel="stylesheet" href="all_product.css">
		  <link rel="stylesheet" href="orders.css">
		 <link rel = "icon" href = "logo.png" type = "image/x-icon">
		<link rel="stylesheet" href="slide.css">
   		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
   		 <script src="admin.js"></script>
   		 <script src="quary.js"></script>
   		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script type="text/javascript">
var timestamp = '<?=time();?>';
function updateTime(){
  $('#time').html(Date(timestamp));
  timestamp++;
}
$(function(){
  setInterval(updateTime, 1000);
});
</script>
	</head>
	<body>
	
<?php
session_start();
?>

<center><h1>DigiCart</h1></center>

<!--<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Login</button>-->

<div id="header">
<span id="opener" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
<p id="time"></p>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="all_product.php">All Products</a>
   <a href="user.php">Clients</a>
  <a href="insert.html">Add User</a>
   <a href="#">Add Products</a>
  <a href="orders.php">Orders</a>
</div>
</div>

	
<?php
			require_once('conn.php');
			$sql  ="SELECT * FROM quary";
			//echo "connected";
			
			$result= $conn->query($sql);
			if($result->num_rows>0){
				
				?>
				<div id = "contanar">
<center>


<table id="customers">
		<tr>
		<th>Serial
		<th>UserName
		<th>Problem
		<th>Date
		<th>Answer
		<th colspan="2">Action &nbsp &nbsp
		</tr>
				
				
				
				<?php
				
					while($row = $result->fetch_assoc()) {
						$serial = '$row["serial"]';
						?>
						<tr>
								<td><?php echo $row["serial"]; ?></td>
								<td><?php echo $row["username"]; ?></td>
								<td><?php echo $row["problem"]; ?></td>
								<td><?php echo $row["date"]; ?></td>
								<td id="answer"><?php echo $row["answer"];?></td>
								<td><?php echo"<button  type='button' onclick='chenge($row[serial])'>"?>Answer</button><td>
								
								</form>
						</tr>
						
						
						
						<?php
						  }
						}
	else{ echo"<center>"."<h2>"." The product you are looking for is not available right now"."</h2>"."</center";
		}
$conn->close();
		?>
		
		</table>
</div>

<div class="form-popup" id="myForm">
  <form action="update_quary.php" method="post" class="form-container">
    <h1>Answer </h1>
	<input type="hidden" name="serial" id="idss">
	
   <textarea name="ans" > ok</textarea>

    <button type="submit" class="btn">Update</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
</div>
 <!--button class="open-button" onclick="openForm()">Open Form</button-->


</body>
</html>

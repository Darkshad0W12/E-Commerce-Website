
function chenge(s) {
	
  document.getElementById("idss").value = s;
  document.getElementById("myForm").style.display = "block";
}
<?php

require_once'conn.php';
			$serial= $_GET["serial"];
			 $sql = "DELETE FROM `mobile` WHERE `serial` = '$serial'";
			 if($conn->query($sql)===TRUE){
				header('Location:all_product.php');
			 }

?>
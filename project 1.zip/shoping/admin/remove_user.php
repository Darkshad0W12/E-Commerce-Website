<?php

require_once'conn.php';
			$serial= $_GET["serial"];
			 $sql = "DELETE FROM `data` WHERE `serial` = '$serial'";
			 if($conn->query($sql)===TRUE){
				header('Location:user.php');
			 }

?>
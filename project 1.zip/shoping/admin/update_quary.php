<?php 
$serial = $_POST["serial"];
$answer = $_POST["ans"];
// echo $serial ;
// echo $answer ;


require_once("conn.php");
 $sql = "UPDATE `quary` SET `answer`='$answer' WHERE serial = $serial";
   if($conn->query($sql)===TRUE){
				header('Location:quaries.php');
			 }



?>
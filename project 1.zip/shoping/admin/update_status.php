<?php 
 $val  = $_POST["status"];
 $val2  = $_POST["serial"];
 echo $val;
 echo $val2;
  
  
  require_once("conn.php");
  $sql = "UPDATE `orders` SET delivery = '$val' WHERE serial = '$val2' ";
   if($conn->query($sql)===TRUE){
				header('Location:orders.php');
			 }
  
   ?>
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" 
rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
<link rel="stylesheet" href="bill.css">
</head>
<body>
<?php
session_start();
$id = $_GET["id"];
	$name= $_SESSION["user"];
	$email= $_SESSION["email"];
	$address= $_SESSION["address"];
	$phone= $_SESSION["phone"];
	
	$servername="localhost";
			$username = "root";
			$passwoard ="";
			$dbname="reg";
			$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			//echo "connected";
			$username="";
			$username= $_SESSION["email"]; 
			$sql="SELECT * FROM orders WHERE serial = '$id'";
			$total="SELECT SUM(price) as `ttl` FROM orders WHERE email='$username'";
			$result= $conn->query($sql);
			$tresult= $conn->query($total);
			$sum=mysqli_fetch_array($tresult);
			if($result->num_rows>0){
				$row = $result->fetch_assoc();
				$username=$_SESSION["uname"];
				$model=$row["model"];
				$price=$row["price"];
				$tid= $row["id"];
				$time= $row["time"];
				$to=$sum['ttl'];
			}
			
			if($tid=="COD"){
				$tid="Cod(Not yet paid)";
			}
?>

	<center>
	<h1>DigiCart</h1>
	</center> 
	<div class="biller">
	Biller : DigiCart	<br>
	Bill No : - <?php echo rand() ?>
	</div>
	<div class="reciver">
	Name: <?php echo $name?><br>
	Phone: <?php echo $phone?><br>
	Billing Address: <?php echo $address?><br><br><br>
	</div>
	
	<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Product</th>
      <th scope="col">Price</th>
      <th scope="col">Tranjaction-Id</th>
      <th scope="col">Date/Time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td><?php echo $model?></td>
      <td><?php echo $price?></td>
      <td><?php echo $tid?></td>
      <td><?php echo $time?></td>
    </tr>
    <tr>
      
      <td colspan="4" align=right>Total:- </td>
      <td > <?php echo $price?></td>
    </tr>
  </tbody>
</table><br><br>
Date :-<?php echo date("Y/m/d"); ?>
<div class="signer">Authorised by:-<font>DigiCart</font></div>
	
</body>
<script>
window.print();
</script>
</html>



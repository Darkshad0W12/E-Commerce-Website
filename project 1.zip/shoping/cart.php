<html>
	<head><title>Add to Cart</title>
	</head>
	<body bgcolor="lightblue">
<?php
session_start();
?>
	<?php
if(isset($_SESSION["uname"])){
			require_once'conn.php'; 
			$username=$_SESSION["uname"];
			$email=$_SESSION["email"];
			$brand="";
			$model="";
			$price="";
			$serial= (isset($_GET["serial"])?$_GET["serial"]:$_SESSION["serial"]);
			$sql="SELECT * FROM mobile WHERE serial = $serial";
			$result= $conn->query($sql);
			if($result->num_rows>0){
				
					while($row = $result->fetch_assoc()) {
						$price=$row["price"];
						$model=$row["model"];
						$brand = $row["brand"];
					}
			}
			
			
     $sql="INSERT INTO cart (username,email,brand,model,price)
 VALUES('$username','$email','$brand','$model','$price')";

if($conn->query($sql)===TRUE){
			echo"<script> alert('Added to cart');
			window.location.href='/phone/$model ';
			
				</script>";	
}
			
else{echo "error".$sql."<br>".$conn->error;
}
			$conn->close();
				}
else{echo "<script>
alert('Login To Add item In Cart');
window.location.href='http://localhost:8070/dashboard/somnath/database/shoping';
</script>";

	}

		?>


	</body>
</html>
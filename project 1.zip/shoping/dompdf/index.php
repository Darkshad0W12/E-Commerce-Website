<?php
require_once 'autoload.inc.php';

use Dompdf\Dompdf;
	
session_start();
	$id = $_GET["id"];
			$servername="localhost";
			$username = "root";
			$passwoard ="";
			$dbname="reg";
			$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			//echo "connected";
			$username="";
			$username= $_SESSION["email"]; 
			$sql="SELECT * FROM orders WHERE id = '$id'";
			$total="SELECT SUM(price) as `ttl` FROM orders WHERE email='$username'";
			$result= $conn->query($sql);
			$tresult= $conn->query($total);
			$sum=mysqli_fetch_array($tresult);
			if($result->num_rows>0){
				$row = $result->fetch_assoc();
				$dompdf = new Dompdf();
				$username=$_SESSION["uname"];
				$model=$row["model"];
				$price=$row["price"];
				$time= $row["time"];
			
				$dompdf->loadHtml(
				'
				<html>
<head>

</head>
<body>
<center>
	<table class="table" border=1>
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td colspan="2">Larry the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table></center>

<a href= go.html>fxfdrgd</a>
</body>
</html>'
				);
				$dompdf->setPaper('A4', 'portrait');

$dompdf->render();

$dompdf->stream();
		
				

						}
			else{ echo"<center>"."<h2>"."NO product in your cart"."</h2>"."</center";
				}
			





$conn->close();


?>
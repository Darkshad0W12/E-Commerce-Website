<html>
	<head><title>Forgot Passwoard</title>
	</head>
	<body>
		<?php
			$servername="localhost";
			$username = "root";
			$passwoard ="";
			$dbname="reg";
			$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			//echo "connected";
			$username=$email="";
			$username=$_POST["username"];
			$email=$_POST["mail"];
			$sql="SELECT * FROM data WHERE username = '$username' AND email = '$email' ";
			$result= $conn->query($sql);
			if($result->num_rows>0){
				
					while($row = $result->fetch_assoc()) {
    echo "<h3>". "Hello  " . $row["name"]."<br>"."Phone : " .$row["phone"]."<br>"."Email : " . $row["email"]."<br>"."<br></h3>";
									  

$to_email = $_POST["mail"];
$subject ="Forget password";
$body ="hello mr/ms : ".$row["name"]."  your password is :  ".$row["passwoard"]."  For Account Id : ".$row["username"]."  If u Are not requesting the passwoard then ignore this mail Or Foillow  "."<a href=http://localhost:8070/dashboard/somnath/database/shoping>This link</a>";
//$headers = "From:confarenceteam@gmail.com";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 
if (mail($to_email, $subject, $body, $headers)) {
    echo "Password successfully sent to $to_email...";
						} 
else {
    echo "Email sending failed...";
	}





										}
						}
	else{ echo "please check the details u Entered";}


 



$conn->close();
		?>
	</body>
</html>
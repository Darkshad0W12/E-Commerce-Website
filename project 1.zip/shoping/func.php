<?php 

function sum(int $a,int $b){
 return $a+$b;
}
function product(int $a,int $b){
return $a*$b;
}
function update($sql){
	// echo $sql;
	$servername="localhost";
			$username = "root";
			$passwoard ="";
			$dbname="reg";
			$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
	
	if($conn->query($sql)===TRUE){
		return "PASSWORD CHENGED";
			
}
			
else{
	return $sql."<br>".$conn->error;
}
}

function logout(){
	session_start();
	session_unset();

// destroy the session
session_destroy();
header("Location:index.php");
}

?>
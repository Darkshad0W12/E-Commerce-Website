	<html>
	<head> <link rel="stylesheet" href="home.css">
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		  <link rel="stylesheet" href="login.css">
		<link rel="stylesheet" href="slide.css">
		<link rel="stylesheet" href="quary.css">
   		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
   		<script src="quary.js"></script>	
	</head>
		<body bgcolor="">
		 
<?php
	session_start();
			if(isset($_SESSION["uname"])){
			//echo "connected";
			$username="";
			$username = $_SESSION["uname"];
			$user =$_SESSION["uname"];
			//echo $username;
			$problem ="";
			if(isset($_GET["problem"])){
			$problem=$_GET["problem"];
			require_once'conn.php';
			$sql = "INSERT INTO `quary`(`username`, `problem`) VALUES ('$user','$problem')";
			if($conn->query($sql)===TRUE){
			echo"<script> 
		 alert('Quary Submitted successfully');
	window.location.href='gen_quary.php'</script>";			
	}
			else{echo "error".$sql."<br>".$conn->error;}
			
			}
			}
			else{
							echo"<script> alert('Please Login to Rais Quary');
	window.location.href='index.php'</script>";			
			}
		
		?>
		
		<form method="post" action="search.php">
			<div id="header"><h1 id="h1">DigiCart</h1>
			<input type="text" name='search' id="search" placeholder="Search For Products">
			<button type="submit" id="btn"><i id="search1" class="fas fa-search"></i></button>
			</form>
			<ol>
				
				<li class="ol"><div class="dropdown">
  				<button class="dropbtn" id="more"><a href="#">More</a></button>
  				<div class="dropdown-content">
    				<a href="see_orders.php">orders</a>
 				 </div>
				</div>

				<li class="ol"><a href="see_cart.php"><i class="fas fa-cart-plus"></i>Cart</a>
				<li class="ol"><a href="logout.php">Logout</a> 
			
			</ol>
			</div>
			<ul class="stick">
				<li><div class="dropdown">
  <button class="dropbtn">Mobile</button>
  <div class="dropdown-content">
    <a href="realme.php">Realme</a>
    <a href="samsang.php">Samsang</a>
    <a href="redmi.php">Redmi</a>
	<a href="search1.php?search=poco">Poco</a>
    <a href="search1.php?search=vivo">Vivo</a>
    <a href="search1.php?search=asus">Asus</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Television</button>
  <div class="dropdown-content">
    <a href="#">Sony</a>
    <a href="#">Reliance</a>
    <a href="#">Panasonic</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Laptop</button>
  <div class="dropdown-content">
    <a href="#">Acer</a>
    <a href="#">Lenovo</a>
    <a href="#">Dell</a>
  </div>
</div>

<li><div class="dropdown">
  <button class="dropbtn ">About us</button>
</div>
<li><div class="dropdown ">
  <button class="dropbtn"><i class="fas fa-headset"> Contact us</i></button>
   <div class="dropdown-content">
    <a href="sendmail.php">Mail Us</a>
    <a href="#">Rais Quary</a>
  </div>
</div>

<li><div class="dropdown a">
  <a href="#"><button class="dropbtn" id="profile"><i class="far fa-user"> 	Profile</i></button></a>
</div>		
			</ul>
			
			
			
		<center>	<table class="table" width = 80%>
				<tbody><tr id="tr">
						<th>Quary 
						<th>Answer
				</tbody>
				<?php
				require_once'conn.php';
				$username = $_SESSION["uname"];
				$sql = "SELECT * FROM `quary` WHERE username ='$username'";
			$result= $conn->query($sql);
		if($result->num_rows>0){
		while($row = $result->fetch_assoc()) {
			
			$problem = $row["problem"];
			$answer = $row["answer"];
			$date =$row["date"];
			if($answer == ""){
				$answer = "No answer";
				
			}
			
			?>
			
				 <tr>
					<th>
						<?php echo $problem ?>
						<p id="date"><?php echo $date ?></p>
						
					<th>
						<?php echo $answer ?>
			
		<?php	
			}
					}
			
						
						
						?>
				
			</table>
			
			<br>
			<div class="sent_quary" id="sent_quary">
			 <h2>Sent Quary</h2>
			  <textarea id="subject" name="subject" placeholder="Write Quary.." style="height:200px"></textarea><br><br>
			  <button class="send_quary" id="send_quary" onclick ="test()">Send</button></a>
			</div>
			</center>
			
			<br><br><br>

	<label for="show" class="show-btn"><i class="fas fa-user" id="login"></i><?php echo "  ".$_SESSION["user"]; ?></label>
	</body>
	</html>
		
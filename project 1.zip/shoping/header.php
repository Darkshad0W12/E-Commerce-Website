<html>
	<head> 
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		 <link rel = "icon" href = "logo.png" type = "image/x-icon">
   		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
   		 <script src="index.js"></script>
		 
	</head>
		<body>
		
</body>
		<?php
session_start();
?>
<?php
 $include = true;
 if ($include) { ?>
  <link rel="stylesheet" href="home.css">
   <link rel="stylesheet" href="login.css">
<?php } ?>
	
		<form method="post" action="search.php">
			<div id="header"><h1 id="h1">DigiCart</h1>
			<input type="text" name='search' id="search" placeholder="Search For Products">
			<button type="submit" id="btn"><i id="search1" class="fas fa-search"></i></button>	</form>
			<ol>
				
				<li class="ol"><div class="dropdown">
  				<button class="dropbtn" id="more"><a href="#">More</a></button>
  				<div class="dropdown-content">
  				  <a href="see_orders.php">orders</a>
 				 </div>
				</div>

				<li class="ol"><a href="see_cart.php"><i class="fas fa-cart-plus"></i>Cart</a>
			
			</ol>
			</div>
			
			
			<ul class="stick">
				<li><div class="dropdown">
  <button class="dropbtn">Mobile</button>
  <div class="dropdown-content">
    <a href="realme.php">Realme</a>
    <a href="samsang.php">Samsang</a>
    <a href="redmi.php">Redmi</a>
	<a href="search1.php?search=poco">Poco</a>
    <a href="search1.php?search=vivo">Vivo</a>
    <a href="search1.php?search=asus">Asus</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Television</button>
  <div class="dropdown-content">
    <a href="search1.php?search=sony">Sony</a>
    <a href="search1.php?search=reliance">Reliance</a>
    <a href="search1.php?search=panasonic">Panasonic</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Laptop</button>
  <div class="dropdown-content">
    <a href="search1.php?search=acer">Acer</a>
    <a href="search1.php?search=lenovo">Lenovo</a>
    <a href="search1.php?search=dell">Dell</a>
    <a href="search1.php?search=asus">Asus</a>
    <a href="search1.php?search=Apple">Mac</a>
  </div>
</div>
<li><div class="dropdown">
  <button class="dropbtn a">About us</button>
  
</div>
<li><div class="dropdown a">
  <button class="dropbtn">Contact us</button>
    <div class="dropdown-content">
    <a href="sendmail.php">Mail Us</a>
    <a href="gen_quary.php">Rais Quary</a>
  </div>
</div>

<li><div class="dropdown a">
   <a href="profile.php"><button class="dropbtn" id="profile"><i class="far fa-user"> Profile</i></button></a>
</div>
				
			</ul>
	
<label for="show" class="show-btn"><i class="fas fa-user" id="login"></i><?php echo "  ".$_SESSION["user"]; ?></label>

	</body>
	</html>
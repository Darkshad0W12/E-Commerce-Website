<html>
	<head> <link rel="stylesheet" href="home.css">
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		  <link rel="stylesheet" href="login.css">
		<link rel="stylesheet" href="slide.css">
   		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
	</head>
		<body>
<?php
session_start();
?>
		<form method="post" action="search.php">
			<div id="header"><h1 id="h1">Y-mart</h1><input type="text" name='search' id="search" placeholder="Search For Products"><button type="submit" id="btn"><i id="search1" class="fas fa-search"></i></button>
			<ol>
				
				<li class="ol"><a>More</a>
				<li class="ol"><a><i class="fas fa-cart-plus"></i>Cart</a>
				<li class="ol"><a href="logout.php">Logout</a> 
			
			</ol>
			</div>
			<ul class="stick">
				<li><div class="dropdown">
  <button class="dropbtn">Mobile</button>
  <div class="dropdown-content">
    <a href="realme.php">Realme</a>
    <a href="samsang.php">Samsang</a>
    <a href="redmi.php">Redmi</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Television</button>
  <div class="dropdown-content">
    <a href="#">Brand 1</a>
    <a href="#">Brand 2</a>
    <a href="#">Brand 3</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Laptop</button>
  <div class="dropdown-content">
    <a href="#">Brand 1</a>
    <a href="#">Brand 2</a>
    <a href="#">Brand 3</a>
  </div>
</div>
				
			</ul>
		</form>

<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 9</div>
  <img src="pic1.jpg" style="width:100%">
  <div class="text">Caption Text</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 9</div>
  <img src="pic2.jpg" style="width:100%">
  <div class="text">Caption Two</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 9</div>
  <img src="pic3.jpg" style="width:100%">
  <div class="text">Caption Two</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 9</div>
  <img src="pic4.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>
 <div class="mySlides fade">
  <div class="numbertext">4 / 9</div>
  <img src="pic5.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>
 <div class="mySlides fade">
  <div class="numbertext">5 / 9</div>
  <img src="pic6.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>
 <div class="mySlides fade">
  <div class="numbertext">6 / 9</div>
  <img src="pic7.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>
 <div class="mySlides fade">
  <div class="numbertext">7 / 9</div>
  <img src="pic8.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>
 <div class="mySlides fade">
  <div class="numbertext">8 / 9</div>
  <img src="pic9.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>
 
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
    <span class="dot"></span>
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>
<label for="show" class="show-btn"><i class="fas fa-user"></i><?php echo "  ".$_SESSION["user"]; ?></label>



</body>
</html>

function myFunction() {
  var x = document.getElementById("pass");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

function forget() {
  var myClock = document.getElementById("f_password");
  var cont=document.getElementById("container");
   
   var displaySetting = myClock.style.display;
  if( myClock.style.display === 'none'){
    myClock.style.display = 'block';
  }else{
	   myClock.style.display = 'none';
  }
//cont.style.display = 'none';
}
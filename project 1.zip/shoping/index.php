<html>
	<head> <link rel="stylesheet" href="home.css">
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		  <link rel="stylesheet" href="login.css">
		 <link rel = "icon" href = "logo.png" type = "image/x-icon">
		<link rel="stylesheet" href="slide.css">
   		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
   		 <script src="index.js"></script>
		 <title>DigiCart</title>
		<script>function goto(){
						window.location="privacy_policy.html";
}</script>
	</head>
		<body>
		
</body>
		<?php
session_start();
if(isset($_SESSION["uname"]))
	header("Location:home.php");
?>
	
		<form method="post" action="search.php">
			<div id="header"><h1 id="h1">DigiCart</h1>
			<input type="text" name='search' id="search" placeholder="Search For Products">
			<button type="submit" id="btn"><i id="search1" class="fas fa-search"></i></button>	</form>
			<ol>
				
				<li class="ol"><div class="dropdown">
  				<button class="dropbtn" id="more"><a href="#">More</a></button>
  				<div class="dropdown-content">
  				  <a href="see_orders.php">orders</a>
 				 </div>
				</div>

				<li class="ol"><a href="see_cart.php"><i class="fas fa-cart-plus"></i>Cart</a>
			
			</ol>
			</div>
			
			
			<ul class="stick">
				<li><div class="dropdown">
  <button class="dropbtn">Mobile</button>
  <div class="dropdown-content">
    <a href="realme.php">Realme</a>
    <a href="samsang.php">Samsang</a>
    <a href="redmi.php">Redmi</a>
	<a href="search1.php?search=poco">Poco</a>
    <a href="search1.php?search=vivo">Vivo</a>
    <a href="search1.php?search=asus">Asus</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Television</button>
  <div class="dropdown-content">
    <a href="search1.php?search=sony">Sony</a>
    <a href="search1.php?search=reliance">Reliance</a>
    <a href="search1.php?search=panasonic">Panasonic</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Laptop</button>
  <div class="dropdown-content">
    <a href="search1.php?search=acer">Acer</a>
    <a href="search1.php?search=lenovo">Lenovo</a>
    <a href="search1.php?search=dell">Dell</a>
    <a href="search1.php?search=asus">Asus</a>
    <a href="search1.php?search=Apple">Mac</a>
  </div>
</div>
<li><div class="dropdown">
  <button class="dropbtn a" onclick="goto()">About us</button>
  
</div>
<li><div class="dropdown a">
  <button class="dropbtn">Contact us</button>
    <div class="dropdown-content">
    <a href="sendmail.php">Mail Us</a>
    <a href="gen_quary.php">Rais Quary</a>
  </div>
</div>

<li><div class="dropdown a">
   <a href="profile.php"><button class="dropbtn" id="profile"><i class="far fa-user"> Profile</i></button></a>
</div>
				
			</ul>
	

	

<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 9</div>
  <img src="pic1.jpg" style="width:100%">
  <div class="text">Caption Text</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 9</div>
  <img src="pic2.jpg" style="width:100%">
  <div class="text">Caption Two</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 9</div>
  <img src="pic3.jpg" style="width:100%">
  <div class="text">Caption Two</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 9</div>
  <img src="pic4.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>
 <div class="mySlides fade">
  <div class="numbertext">4 / 9</div>
  <img src="pic5.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>
 <div class="mySlides fade">
  <div class="numbertext">5 / 9</div>
  <img src="pic6.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>
 <div class="mySlides fade">
  <div class="numbertext">6 / 9</div>
  <img src="pic7.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>
 <div class="mySlides fade">
  <div class="numbertext">7 / 9</div>
  <img src="pic8.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>
 <div class="mySlides fade">
  <div class="numbertext">8 / 9</div>
  <img src="pic9.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>
 
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
    <span class="dot"></span>
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>


    
    <div class="center">
      <input type="checkbox" id="show">
      <label for="show" class="show-btn" id="login">Login</label>
      <div class="container" id="container">
        <label for="show" class="close-btn fas fa-times" title="close"></label>
        <div class="text"> DigiCart</div>
<form method="post" action="login.php">
          <div class="data">
            <label>Email or Phone</label>
            <input type="text" name="username" required>
          </div>
<div class="data">
            <label>Password</label>
            <input type="password" name="passwoard" id="pass" required>
			<i class="fas fa-eye-slash " id= "show_pass"onclick="myFunction()"></i>
          </div>
<div class="forgot-pass">
<label onclick="forget()">Forgot Password?</label></div>
<div class="btn">
            <div class="inner">
</div>
<button type="submit">login</button>
          </div>
<div class="signup-link">
Not a member? <a href="insert.html">Signup now</a></div>
</form>

</div>
<div id="f_password">
<form method="post" action="f_password.php">
				<label class=" fas fa-times" id="close_fpass" title="close" align="right" onclick="forget()"></label>
				Name :&nbsp &nbsp &nbsp   <div class="data"><input type="text" name="name">
</div><br><br>
				Username : <div class="data"><input type="text" name="username">
</div><br><br>
				Email :&nbsp &nbsp &nbsp    <div class="data"> <input type="text" placeholder="Enter Email" name="mail" required>
</div><br><br>
				 <input type="submit" value="Reset" class="signupbtn"/>
				</form>
			</div>
</div>







</body>
</html>

<html>
<head><title>logging out</title>
	<body>
<?php
session_start();
?>
	
 <?php

session_unset();

// destroy the session
session_destroy();
header("Location:index.php");
?>

	</body>
</head>
</html>
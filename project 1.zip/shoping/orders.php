<html>
	<head><title>order</title>
	</head>
	<body bgcolor="lightblue">
<?php
session_start();
?>
	<?php
if(isset($_SESSION["uname"])){
			$servername = "localhost";
			$username="root";
			$passwoard ="";
			$dbname= "reg";
	$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			$username=$_SESSION["uname"];
			$email=$_SESSION["email"];
			$brand="";
			$model="";
			$price="";
			$id=$_GET["uid"];
			$serial= (isset($_GET["serial"])?$_GET["serial"]:$_SESSION["serial"]);
			$sql="SELECT * FROM mobile WHERE serial = $serial";
			$result= $conn->query($sql);
			if($result->num_rows>0){
				
					while($row = $result->fetch_assoc()) {
						$price=$row["price"];
						$model=$row["model"];
						$brand = $row["brand"];
						$pid=$row["serial"];
						$time =date("Y-m-d");
						$expected_date = date('Y-m-d', strtotime($time .' +5 day'));
					}
			}
			
			
     $sql="INSERT INTO `orders` (`username`, `model`, `price`, `id`, `email`,`pid`,`expected`) 
VALUES ('$username','$model', $price, '$id','$email','$pid','$expected_date')";

if($conn->query($sql)===TRUE){
			echo"<script> alert('Order placed successfully');
	window.location.href='phone/$model';	</script>";			}
			else{echo "error".$sql."<br>".$conn->error;}
			$conn->close();
				}
else{echo "<script>
alert('Login To place Order');
window.location.href='http://localhost:8070/dashboard/somnath/database/shoping';
</script>";

	}
		?>


	</body>
</html>
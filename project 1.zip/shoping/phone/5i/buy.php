<htmml>
<head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

/* Button used to open the contact form - fixed at the bottom of the page */
.open-button {
  background-color: #555;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;
  position: fixed;
  bottom: 23px;
  right: 28px;
  width: 280px;
}

/* The popup form - hidden by default */
.form-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}

/* Add styles to the form container */
.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}

/* Full-width input fields */
.form-container input[type=text], .form-container input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

/* When the inputs get focus, do something */
.form-container input[type=text]:focus, .form-container input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit/login button */
.form-container .btn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}

/* Add a red background color to the cancel button */
.form-container .cancel {
  background-color: red;
}

/* Add some hover effects to buttons */
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>
</head>

<body>
<?php
session_start();
$price="";
$serial =$_GET["serial"];
$servername="localhost";
			$username = "root";
			$passwoard ="";
			$dbname="reg";
			$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			//echo "connected";
			$sql="SELECT * FROM mobile WHERE serial = $serial";
			$result= $conn->query($sql);
			if($result->num_rows>0){
				
					while($row = $result->fetch_assoc()) {
						$price=$row["price"];
						$model=$row["model"];
						
						
					}
			}


?>
<button id="rzp-button1">Pay</button>
<?php echo $serial ?>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
var model="<?php echo $model ?>";
var name="<?php echo $_SESSION["uname"]; ?>";
var email="<?php echo $_SESSION["email"]; ?>";
var price="<?php echo $price; ?>";
var phone="<?php echo $_SESSION["phone"]; ?>";
price*=100;
var options = {
    "key": "rzp_test_y6J2TsZitgI7Ib", // Enter the Key ID generated from the Dashboard
    "amount":price, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
    "currency": "INR",
    "name": "Y-mart",
    "description": model,
    "image": "logo.png",
    "handler": function (response){
        alert("Transaction Successful Transaction  ID IS :"+ response.razorpay_payment_id);
		id=response.razorpay_payment_id;
		alert(id);
		
	window.location.replace("orders.php?uid="+response.razorpay_payment_id ); 	
        //alert(response.razorpay_order_id);
        //alert(response.razorpay_signature)
    },
    "prefill": {
        "name": name,
        "email": email,
        "contact":phone,
    },
    "notes": {
        "address": "Razorpay Corporate Office"
    },
    "theme": {
        "color": "#3399cc"
    }
};


var rzp1 = new Razorpay(options);
rzp1.on('payment.failed', function (response){
        alert(response.error.code);
        alert(response.error.description);
        alert(response.error.source);
        alert(response.error.step);
        alert(response.error.reason);
        alert(response.error.metadata.order_id);
        alert(response.error.metadata.payment_id);
});
document.getElementById('rzp-button1').onclick = function(e){
    rzp1.open();
    e.preventDefault();
}
</script>

</body>
</html>
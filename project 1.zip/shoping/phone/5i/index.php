	<html>
	<head> <link rel="stylesheet" href="home.css">
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
   		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
		 <style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

/* Button used to open the contact form - fixed at the bottom of the page */
.open-button {
  background-color: #555;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;
  position: fixed;
  bottom: 23px;
  right: 28px;
  width: 280px;
}

/* The popup form - hidden by default */
.form-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}

/* Add styles to the form container */
.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}

/* Full-width input fields */
.form-container input[type=text], .form-container input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

/* When the inputs get focus, do something */
.form-container input[type=text]:focus, .form-container input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit/login button */
.form-container .btn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}

/* Add a red background color to the cancel button */
.form-container .cancel {
  background-color: red;
}

/* Add some hover effects to buttons */
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>
	</head>


		<body>

<?php
session_start();
$price="";
$serial= (isset($_GET["serial"])?$_GET["serial"]:$_SESSION["serial"]);
$_SESSION["serial"] = $serial;
$servername="localhost";
			$username = "root";
			$passwoard ="";
			$dbname="reg";
			$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			//echo "connected";
			$sql="SELECT * FROM mobile WHERE serial = $serial";
			$result= $conn->query($sql);
			if($result->num_rows>0){
				
					while($row = $result->fetch_assoc()) {
						$price=$row["price"];
						$model=$row["model"];
						
						
					}
			}


?>
		
<div class="slideshow-container" align="left">
  <div class="mySlides1">
    <img src="pic1.jpg" style="width:50%">
  </div>

  <div class="mySlides1">
    <img src="pic2.jpg" style="width:50%">
  </div>

  <div class="mySlides1">
    <img src="pic3.jpg" style="width:50%">
  </div>
  
  <div class="mySlides1">
    <img src="pic4.jpg" style="width:50%">
  </div>

  <a class="prev" onclick="plusSlides(-1, 0)">&#10094;</a>
  <a class="next" onclick="plusSlides(1, 0)">&#10095;</a>
  	<h1><p class="price">  &nbsp &nbsp   &nbsp &nbsp price:<?php echo " R/s $price ";?> </p></h1>
	
  
</div>




<script>
var slideIndex = [1,1];
var slideId = ["mySlides1", "mySlides2"]
showSlides(1, 0);
showSlides(1, 1);

function plusSlides(n, no) {
  showSlides(slideIndex[no] += n, no);
}

function showSlides(n, no) {
  var i;
  var x = document.getElementsByClassName(slideId[no]);
  if (n > x.length) {slideIndex[no] = 1}    
  if (n < 1) {slideIndex[no] = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  x[slideIndex[no]-1].style.display = "block";  
}
</script>
<div id ="details">
		<ul type="square">  
			<li><div class="head"> Genarel:</div>
					<ul type="circle">
							<li>In The Box : Handset, Adapter, USB Cable, SIM Card Tool, Screen Protect Film, Booklet with Warranty Card, Quick Guide
							<li>Model Number : RMX2180
							<li>Model Name : C12
							<li>Color : Power Silver
							<li>Browse Type	: Smartphones
							<li>SIM Type : Dual Sim
							<li>Hybrid Sim Slot : No
							<li>Touchscreen	: Yes

					</ul>
			<li><div class="head">Display:</div> 
					<ul type="circle">
							<li>Display Size : 16.56 cm (6.52 inch)
							<li>Resolution : 1600 x 720 Pixels
							<li>Other Display Features : 20:9 Screen Ratio, 88.70% Screen-to-body Ratio,<br> Screen Contrast: 800:1 (Min), 1200:1 (Typ), 60 Hz Screen Refresh Rate, 71% Color Saturation,<br> 420 nit Maximum Brightness, Sunlight Screen Support, GG3 Touch Screen Glass Material, 120 Hz Touch Sampling Rate, COG Screen Sealing Process							

					</ul>

			<li><div class="head">Os:</div>
					<ul type="circle">
							<li>Operating System : Android 10
							<li>Processor Type : Mediatek Helio G35
							<li>Processor Core : Octa Core
							<li>Primary Clock Speed	: 2.3 GHz
							<li>Operating Frequency	: GSM: 850/900/1800/1900, WCDMA: B1/B5/B8, FDD LTE: B1/B3/B5/B8, TDD LTE: B38/B40/B41 (2535-2655 MHz)

					</ul>

			<li><div class="head">Memoy:</div> 
					<ul type="circle">
							<li>Internal Storage :32 GB
							<li>RAM	: 3 GB
							<li>Expandable Storage	: 256 GB
							<li>Expandable Storage	: 256 GB
							<li>Supported Memory Card Type : microSD

					</ul>
			<li><div class="head">Camera:</div> 
					<ul type="circle">
							<li>Primary Camera Available  : Yes
							<li>Primary Camera : 13MP + 8MP + 2MP + 2MP
							<li>Primary Camera Features : 13MP (Rear Main) + 8MP (Ultra Wide) + 2MP (Mono) + 2MP (Retro) Rear Camera Setup, <br>Sensor Sizes/Pixel Data: 1/3 inch, 1.12um (13MP) + 1/4 inch, 1.12um (8MP) + 1/5 inch, 1.75um (2MP), 1/5 inch, 1.75um (2MP), CMOS Sensor, Focusing Method: PDAF (13MP) + FF (8M) + FF (2MP) + FF (2MP), Aperture: f/2.2 (13MP) + f/2.25 (8MP) + f/2.4 (2MP) + f/2.4 (2MP),<br> Lens Number: 5P (13MP) + 5P (8MP) + 3P (2MP) + 3P (2MP), Slow Motion: 720p at 90 fps, Characteristic Function for Photograph: Beauty, Filter, HDR, Panoramic View, Portrait, Timelapse, Slo-mo, NightScape, Expert, Ways of Taking Photos: Timer, Touch, Gesture, Volume Button, Fingerprint
							<li>Secondary Camera : 8MP Front Camera
							<li>Secondary Camera Features : 8MP Front Camera, Sensor Sizes/Pixel Data: 1/4 inch, 1.12um, CMOS Sensor, Focusing Mode: FF, f/2.0 Aperture, 5P Lens,<br> Ways of Taking Photos: Timer, Touch, Gesture, Volume Button, Fingerprint,<br> Characteristic Function for Photograph: Beauty, Filter, HDR, Panoramic View, Portrait, Timelapse

					</ul>

			<li><div class="head">Connectivity:</div> 
					<ul type="circle">
							<li>Network Type : 4G VOLTE, 4G, 3G, 2G
							<li>Supported Networks : 4G VoLTE, 4G LTE, WCDMA, GSM
							<li>Internet Connectivity : 4G, 3G, Wi-Fi, EDGE, GPRS
							<li>Bluetooth Version : v5.0
							<li>Wi-Fi Version : 802.11b/g/n (2.4 GHz)

					</ul>

			<li><div class="head">Others:</div>
				 	<ul type="circle">
							<li>WidtH : 75.9 mm
							<li>Supported Networks : 4G VoLTE, 4G LTE, WCDMA, GSM
							<li>HeighT : 164.5 mm
							<li>Depth : 9.8 mm
							<li>Weight : 209 g

					</ul>
					
	

		</ul> 


</div>
<?php 
$link="buy.php?serial=$serial";
$cart="../../cart.php?serial=$serial";
$cod="../../orders.php?uid=COD& serial=$serial"
?>

<br><button class="button" style="vertical-align:middle" class="open-button" onclick="openForm()"><span style="horizondal-align:middle">
Buy Now </span></button>
 <?php echo "<a href='$cart'>" ?>  <button class="button" style="horizondal-align:middle" id="cart"><span style="horizondal-align:middle">Add To Cart </span></button><?php echo"</a>" ?><br><br>


<div class="form-popup" id="myForm">
  <form action="/action_page.php" class="form-container">
   <?php echo"<a href='$cod'>"?><button type="button" class="btn">COD</button><?php echo"</a>"?>
    <button type="button" class="btn cancel" id="rzp-button1">Pay Now</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Cancle</button>
  </form>
</div>

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
var model="<?php echo $model ?>";
var name="<?php echo $_SESSION["uname"]; ?>";
var email="<?php echo $_SESSION["email"]; ?>";
var price="<?php echo $price; ?>";
var phone="<?php echo $_SESSION["phone"]; ?>";
price*=100;
var options = {
    "key": "rzp_test_B59PbKFKLc0veZ", // Enter the Key ID generated from the Dashboard
    "amount":price, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
    "currency": "INR",
    "name": "DigiCart",
    "description": model,
    "image": "logo.png",
    "handler": function (response){
        alert("Transaction Successful Transaction  ID IS :"+ response.razorpay_payment_id);
		id=response.razorpay_payment_id;
		alert(id);
		
	window.location.replace("../../orders.php?uid="+response.razorpay_payment_id ); 	
        //alert(response.razorpay_order_id);
        //alert(response.razorpay_signature)
    },
    "prefill": {
        "name": name,
        "email": email,
        "contact":phone,
    },
    "notes": {
        "address": "Razorpay Corporate Office"
    },
    "theme": {
        "color": "#3399cc"
    }
};


var rzp1 = new Razorpay(options);
rzp1.on('payment.failed', function (response){
        alert(response.error.code);
        alert(response.error.description);
        alert(response.error.source);
        alert(response.error.step);
        alert(response.error.reason);
        alert(response.error.metadata.order_id);
        alert(response.error.metadata.payment_id);
});
document.getElementById('rzp-button1').onclick = function(e){
    rzp1.open();
    e.preventDefault();
}
</script>




</body>
</html>

<html>
	<head><title>order</title>
	</head>
	<body bgcolor="lightblue">
<?php
session_start();
?>
	<?php
if(isset($_SESSION["uname"])){
			$servername = "localhost";
			$username="root";
			$passwoard ="";
			$dbname= "reg";
	$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			$username=$_SESSION["uname"];
			$email=$_SESSION["email"];
			$brand=$_SESSION["brand"];
			$model=$_SESSION["model"];
			$price=$_SESSION["price"];
			$id=$_GET["uid"];
     $sql="INSERT INTO `orders` (`username`, `model`, `price`, `id`, `email`,`date`) 
VALUES ('$username','$model', $price, '$id','$email','10/05/15')";

if($conn->query($sql)===TRUE){
			echo"<script> alert('Order placed successfully');
	window.location.href='http://localhost:8070/dashboard/somnath/database/shoping/phone/$model';	</script>";			}
			else{echo "error".$sql."<br>".$conn->error;}
			$conn->close();
				}
else{

	}

		?>


	</body>
</html>
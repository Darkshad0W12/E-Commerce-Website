	<html>
	<head>
	<link rel="stylesheet" href="../tv_css.css">
	<link rel="stylesheet" href="../rating_table_device.css">
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
   		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
   		 <script src="../tv.js"></script>
		 
		 <meta name="viewport" content="width=device-width, initial-scale=1.0">
		 <script>

function display(){
	var d  = document.getElementById("date").value;
	alert(d);
	
}

</script>
	</head>


		<body>

<?php
session_start();

$price="";
$serial= (isset($_GET["serial"])?$_GET["serial"]:$_SESSION["serial"]);
$_SESSION["serial"] = $serial;
$servername="localhost";
			$username = "root";
			$passwoard ="";
			$dbname="reg";
			$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			//echo "connected";
			$sql="SELECT * FROM mobile WHERE serial = $serial";
			$result= $conn->query($sql);
			if($result->num_rows>0){
				
					while($row = $result->fetch_assoc()) {
						$price=$row["price"];
						$model=$row["model"];
						$details = $row["details"];
						$brand = $row["brand"];
						$pic=$row["pic"];
						
						
					}
			}


?>
<div>
<?php  echo "<img src='$pic' width='30%'>"?> 
<h2 id="not">₹ 50000</h2>
<h2>₹ <?php echo $price?></h2>

</div>

<div class="full_details">
<label class="point">Manufature</label>
<li>Brand</label> : <?php echo $brand?><br>
<li>Model</label>:<?php echo $model?><br>
<li>Price </label>: </br>
<label class="point">Details</label>
<li>In The Box : 1 TV Unit, Remote, Wall Mount, User Manual, 2 AAA Battery
<li>Model Name	:32PATH0011</li>
<li>Color:  Black</li>
<li>Display Size : 80 cm (32)
<li>Screen Type	 :	LED
<li>HD Technology & Resolution	 : HD Ready, 1366 x 768
<li>3D	 :	No
<li>Smart TV	 :	Yes
<li>Curve TV	: 	No
<li>Series	 :	9A Series
<li>Touchscreen	:	No
<li>Motion Sensor	: 	No
<li>HDMI	: 	3
<li>USB	 :	2
<li>Wi-Fi Type	 :	802.11a/b/g/n
<li>Built In Wi-Fi	 :	Yes

<li>Launch Year	 :	2020
<li>Internet Features
<li>Built In Wi-Fi	 :	Yes
<li>3G Dongle Plug and Play	 :	No
<li>Ethernet (RJ45)	 :	1
<br><label class="point">Other Internet Features </label>
<br> <li>More Than 5000 Plus Apps and Games Like Prime Video, Hotstar, Zee5, Sony LIV, 
<br>Airplay, Built-in Chromecast, Google Play Store with 500,000 Plus TV Shows, Movies and Games, Google Assistant, Unlimited Content, 2.4 GHz Built-in WiFi
<br><label class="point">Connectivity Features</label>
<li>HDMI	 :3 Rear
<li>USB	 :2 Side
<li>Digital Audio Output	 :	Yes
<li>RF Connectivity Input	 :	Yes
<li>RF Connectivity Output	 :	No
<li>Other Connectivity Features	 :Network PM44-11BP 100M Ethernet Support (10/100M, DHCP), Browser, Support HDMI-ARC
<br>
<label class="point">Video Features</label><br>
<li>Brightness	 :	400 nits
<li>Contrast Ratio	 :	500000:1 (Dynamic)
<li>Analog TV Reception	 :	Yes
<li>Digital TV Reception	:	Yes


</div>







<?php 
$link="buy.php?serial=$serial";
$cart="../../cart.php?serial=$serial";
$cod="../../orders.php?uid=COD& serial=$serial"
?>






<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>

<div class="form-popup" id="myForm">
  <form action="/action_page.php" class="form-container">
   <?php echo"<a href='$cod'>"?><button type="button" class="btn">COD</button><?php echo"</a>"?>
    <button type="button" class="btn cancel" id="rzp-button1">Pay Now</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Cancle</button>
  </form>
</div>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
var model="<?php echo $model ?>";
var pic="<?php echo $pic ?>";
var name="<?php echo $_SESSION["uname"]; ?>";
var email="<?php echo $_SESSION["email"]; ?>";
var price="<?php echo $price; ?>";
var phone="<?php echo $_SESSION["phone"]; ?>";
price*=100;
var options = {
    "key": "rzp_test_B59PbKFKLc0veZ", // Enter the Key ID generated from the Dashboard
    "amount":price, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
    "currency": "INR",
    "name": "DigiCart",
    "description": model,
    "image": pic,
    "handler": function (response){
        alert("Transaction Successful Transaction  ID IS :"+ response.razorpay_payment_id);
		id=response.razorpay_payment_id;
		alert(id);
		
	window.location.replace("../../orders.php?uid="+response.razorpay_payment_id ); 	
        //alert(response.razorpay_order_id);
        //alert(response.razorpay_signature)
    },
    "prefill": {
        "name": name,
        "email": email,
        "contact":phone,
    },
    "notes": {
        "address": "Razorpay Corporate Office"
    },
    "theme": {
        "color": "#3399cc"
    }
};


var rzp1 = new Razorpay(options);
rzp1.on('payment.failed', function (response){
        alert(response.error.code);
        alert(response.error.description);
        alert(response.error.source);
        alert(response.error.step);
        alert(response.error.reason);
        alert(response.error.metadata.order_id);
        alert(response.error.metadata.payment_id);
});
document.getElementById('rzp-button1').onclick = function(e){
    rzp1.open();
    e.preventDefault();
}
</script>


<ul>

<br><div id ="buttons_all"><li class="b"><button class="button" style="vertical-align:middle" class="open-button" onclick="openForm()">
				<span style="horizondal-align:middle">
Buy Now </span></button></li>
 <?php echo "<a href='$cart'>" ?> <li class="b"> <button class="button" style="horizondal-align:middle" id="cart">
				<span style="horizondal-align:middle">Add To Cart </span></button></li><?php echo"</a>" ?></div><br><br>
</ul>
<br>
<br>
<span id="rating>"
<br>
<?php require_once(".././../rating_table.php");?>
</span>
</body>
</html>

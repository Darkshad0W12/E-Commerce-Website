
function test(){
	
	var problems;
	problems =document.getElementById("subject").value;
	if(problems==null || problems == ""){
		alert("please explain how can we help you");
	}
	else{
		window.location.href='gen_quary.php?problem='+problems;
	}
}


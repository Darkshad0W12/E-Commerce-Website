<?php 
session_start();
$rate=$_GET["A"];
$pid=$_GET["B"];
$review=$_GET["C"];
$uid=$_SESSION["uname"];
echo $rate ;
echo $pid;
echo $review;
require_once("conn.php");
$sql = "INSERT INTO `rating`(pid,star,username, review) VALUES ('$pid','$rate','$uid','$review')";
if($conn->query($sql)===TRUE){
	echo "success";
}else{
	echo "error".$sql."<br>".$conn->error;
}

?>
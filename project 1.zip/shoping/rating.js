 function test(y){
	const x= document.getElementById("s5").value;
	const z= document.getElementById("textarea").value;
	// alert(x);
		// window.location.replace("rate.php?A"+x); 
		 window.location.href = "rate.php?A=" + x + "&B=" + y +"&C=" + z; ;
	}


function rate(x){
document.getElementById("s5").value=x;
	//  alert(x);
	
		
}

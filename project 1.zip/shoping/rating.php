<?php 
$pid=$_GET["pid"];
?>

<!DOCTYPE html> 
<html lang="en" dir="ltr" bgcolor="aqua">
  <head>
 
    <meta charset="utf-8">
    <title>Star Rating</title>
    <link rel="stylesheet" href="rating.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
	<script src="rating.js"/>
  </head>
  <body>
  <script src="rating.js"></script>
    <div class="container">
       
      <div class="star-widget">
	
        <input type="radio" name="rate" id="rate-5" onclick="rate(5)">
		<input type="hidden" id="s5">
        <label for="rate-5" class="fas fa-star"></label>
        <input type="radio" name="rate" id="rate-4" onclick="rate(4)">
        <label for="rate-4" class="fas fa-star"></label>
        <input type="radio" name="rate" id="rate-3" onclick="rate(3)">
        <label for="rate-3" class="fas fa-star"></label>
        <input type="radio" name="rate" id="rate-2" onclick="rate(2)">
        <label for="rate-2" class="fas fa-star"></label>
        <input type="radio" name="rate" id="rate-1" onclick="rate(1)">
        <label for="rate-1" class="fas fa-star"></label>
        <form action="#" method="get" class="main">
          <header id="header"></header>
		    <input type="hidden" id="rating" name="rating" value="12">
          <div class="textarea">
            <textarea cols="30" id="textarea" placeholder="Describe your experience.."></textarea>
          </div>
          <div class="btn">
           <?php echo"<button onclick='test($pid)' type='button' >Post</button>" ?>
			
          </div>
	
        </form>
      </div>
    </div>


  </body>
</html>


						<html>
<head>
<link rel="stylesheet" href="rating_table.css">
</head>

<body id="body">
<div class="container">

<span class="table">
<table>


<?php
		// session_start();
		
		require_once("conn.php");
		$pid= (isset($_GET["serial"])?$_GET["serial"]:$_SESSION["pid"]);
$_SESSION["pid"] = $serial;
		$sql = "SELECT * FROM `rating` WHERE `pid` =$pid";
		$result= $conn->query($sql);
			if($result->num_rows>0){
				
					while($row = $result->fetch_assoc()) {
						if($row["star"]==1){
							$star = "⭐";
						}
						else if($row["star"]==2){
							$star = "⭐⭐";
						}
						else if($row["star"]==3){
							$star = "⭐⭐⭐";
						}else if($row["star"]==4){
							$star = "⭐⭐⭐⭐";
						}
						else if($row["star"]==5){
							$star = "⭐⭐⭐⭐⭐";
						}
						?>
						
						<tr>
							<td><?php echo $row["username"];?></th>
							

							<th><?php echo $star;?></th>
							<th><?php echo $row["review"];?></th>
								


						
						
						
						<?php
			}
			
			}

?>
</table>
</span>
</div>

<body>

</html>
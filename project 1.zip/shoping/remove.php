<?php

require_once'conn.php';
			$serial= $_GET["serial"];
			 $sql = "DELETE FROM `cart` WHERE `serial` = '$serial'";
			 if($conn->query($sql)===TRUE){
				header('Location:see_cart.php');
			 }

?>
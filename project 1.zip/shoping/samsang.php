<html>
	<head><title>login</title>
	</head>
	<body bgcolor="lightblue">
		<?php
			$servername="localhost";
			$username = "root";
			$passwoard ="";
			$dbname="reg";
			$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			//echo "connected";
			$sql="SELECT * FROM mobile WHERE brand = 'Samsang' ";
			$result= $conn->query($sql);
			if($result->num_rows>0){
				
					while($row = $result->fetch_assoc()) {
	
   echo "<table border='1' cellspacing='10'>".
			"<tr>".
				"<th >";

$image=$row["pic"];
$link='phone/'.$row["model"].'?serial='.$row["serial"];
echo"<a href='$link '>"."<img src='$image' width='200'>"."</a>";
    echo "<br>"."Brand : " . $row["brand"]."<br>"."Model : " .$row["model"]."<br>"."price : " . $row["price"]."<br>".$row["storage"];
					
	  				



			echo "<th collspan='4' rowspan='5'>";
			

$image=$row["pic"];
$link='phone/'.$row["model"].'?serial='.$row["serial"];
echo"<a href='$link '>"."<img src='$image' width='200'>"."</a>";
    echo "<br>"."Brand : " . $row["brand"]."<br>"."Model : " .$row["model"]."<br>"."price : " . $row["price"]."<br>".$row["storage"];
	
	echo "<th collspan='4' rowspan='5'>";
			

$image=$row["pic"];
$link='phone/'.$row["model"].'?serial='.$row["serial"];
echo"<a href='$link '>"."<img src='$image' width='200'>"."</a>";
    echo "<br>"."Brand : " . $row["brand"]."<br>"."Model : " .$row["model"]."<br>"."price : " . $row["price"]."<br>".$row["storage"];
	
	
	echo "<th collspan='4' rowspan='5'>";
			

$image=$row["pic"];
$link='phone/'.$row["model"].'?serial='.$row["serial"];
echo"<a href='$link '>"."<img src='$image' width='200'>"."</a>";
    echo "<br>"."Brand : " . $row["brand"]."<br>"."Model : " .$row["model"]."<br>"."price : " . $row["price"]."<br>".$row["storage"];
	
	
	echo "<th collspan='4' rowspan='5'>";
			

$image=$row["pic"];
$link='phone/'.$row["model"].'?serial='.$row["serial"];
echo"<a href='$link '>"."<img src='$image' width='200'>"."</a>";
    echo "<br>"."Brand : " . $row["brand"]."<br>"."Model : " .$row["model"]."<br>"."price : " . $row["price"]."<br>".$row["storage"];
	
	
	echo "<th collspan='4' rowspan='5'>";
			

$image=$row["pic"];
$link='phone/'.$row["model"].'?serial='.$row["serial"];
echo"<a href='$link '>"."<img src='$image' width='200'>"."</a>";
    echo "<br>"."Brand : " . $row["brand"]."<br>"."Model : " .$row["model"]."<br>"."price : " . $row["price"]."<br>".$row["storage"];
					
	  				
			echo "</tr>"."</table>";
//header("Location:index.html");
						  }
						}
	else{ echo"<center>"."<h2>"." The product you are looking for is not available right now"."</h2>"."</center";
		}






$conn->close();
		?>

	</body>
</html>
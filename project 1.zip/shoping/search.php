<html>
	<head> <link rel="stylesheet" href="home.css">
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		  <link rel="stylesheet" href="login.css">
   		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
	</head>
		<body>
<?php
session_start();
?>
		<form method="post" action="search.php">
			<div id="header"><h1 id="h1">DigiCart</h1><input type="text" name='search' id="search" placeholder="Search For Products"><button type="submit" id="btn"><i id="search1" class="fas fa-search"></i></button></form>
			<ol>
				
				<li class="ol"><div class="dropdown">
  				<button class="dropbtn" id="more"><a href="#">More</a></button>
  				<div class="dropdown-content">
    				<a href="see_orders.php">orders</a>
 				 </div>
				</div>


				<li class="ol"><a href="see_cart.php"><i class="fas fa-cart-plus"></i>Cart</a>
				<li class="ol"><a href="logout.php">Logout</a> 
			
			</ol>
			</div>
			<ul class="stick">
				<li><div class="dropdown">
  <button class="dropbtn">Mobile</button>
  <div class="dropdown-content">
    <a href="realme.php">Realme</a>
    <a href="samsang.php">Samsang</a>
    <a href="redmi.php">Redmi</a>
	<a href="search1.php?search=poco">Poco</a>
    <a href="search1.php?search=vivo">Vivo</a>
    <a href="search1.php?search=asus">Asus</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Television</button>
  <div class="dropdown-content">
    <a href="search1.php?search=sony">Sony</a>
    <a href="search1.php?search=reliance">Reliance</a>
    <a href="search1.php?search=panasonic">Panasonic</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Laptop</button>
 <div class="dropdown-content">
    <a href="search1.php?search=acer">Acer</a>
    <a href="search1.php?search=lenovo">Lenovo</a>
    <a href="search1.php?search=dell">Dell</a>
    <a href="search1.php?search=asus">Asus</a>
    <a href="search1.php?search=Apple">Mac</a>
  </div>
</div>
				
			</ul>
		
<label for="show" class="show-btn"><i class="fas fa-user"></i><?php echo "  ".$_SESSION["user"]; ?></label>
<a href="index.php">back</a>

	<?php

if(isset($_SESSION["uname"])){
			$servername="localhost";
			$username = "root";
			$passwoard ="";
			$dbname="reg";
			$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			//echo "connected";
			$username="";
			$username=$_POST["search"];
			$sql="SELECT * FROM mobile WHERE model like '$username%' OR brand like '$username%' OR storage like '%$username%' OR price <='$username' OR details like '%$username%'";
			$result= $conn->query($sql);
			if($result->num_rows>0){
				
					while($row = $result->fetch_assoc()) {
	
    echo "<table  border='0' cellspacing='10'>".
			"<tr>".
				"<th  >";
$image=$row["pic"];
					$link='phone/'.$row["model"].'?serial='.$row["serial"];
					
echo"<a href='$link'>"."<img src='$image' width='200'>"."</a>";
    echo "<br>"."Brand : " . $row["brand"]."<br>"."Model : " .$row["model"]."<br>"."price : " . $row["price"]."<br>".$row["storage"];
					
	  				



			echo "<th collspan='4' rowspan='5'>";
			

$image=$row["pic"];
$link='phone/'.$row["model"].'?serial='.$row["serial"];
echo"<a href='$link'>"."<img src='$image' width='200'>"."</a>";
    echo "<br>"."Brand : " . $row["brand"]."<br>"."Model : " .$row["model"]."<br>"."price : " . $row["price"]."<br>".$row["storage"];
	
	
	echo "<th collspan='4' rowspan='5'>";
			

$image=$row["pic"];
$link='phone/'.$row["model"].'?serial='.$row["serial"];
echo"<a href='$link'>"."<img src='$image' width='200'>"."</a>";
    echo "<br>"."Brand : " . $row["brand"]."<br>"."Model : " .$row["model"]."<br>"."price : " . $row["price"]."<br>".$row["storage"];
	
	
	echo "<th collspan='4' rowspan='5'>";
			

$image=$row["pic"];
$link='phone/'.$row["model"].'?serial='.$row["serial"];
echo"<a href='$link'>"."<img src='$image' width='200'>"."</a>";
    echo "<br>"."Brand : " . $row["brand"]."<br>"."Model : " .$row["model"]."<br>"."price : " . $row["price"]."<br>".$row["storage"];
	
	
	echo "<th collspan='4' rowspan='5'>";
			

$image=$row["pic"];
$link='phone/'.$row["model"].'?serial='.$row["serial"];
echo"<a href='$link'>"."<img src='$image' width='200'>"."</a>";
    echo "<br>"."Brand : " . $row["brand"]."<br>"."Model : " .$row["model"]."<br>"."price : " . $row["price"]."<br>".$row["storage"];
	
	
	
	echo "<th collspan='4' rowspan='5'>";
			

$image=$row["pic"];
$link='phone/'.$row["model"].'?serial='.$row["serial"];
echo"<a href='$link'>"."<img src='$image' width='200'>"."</a>";
    echo "<br>"."Brand : " . $row["brand"]."<br>"."Model : " .$row["model"]."<br>"."price : " . $row["price"]."<br>".$row["storage"];
	
	
	
	
					
	  				
			echo "</tr>"."</table>";
//header("Location:index.html");
						  }
						}
	else{ echo"<center>"."<h2>"." The product you are looking for is not available right now"."</h2>"."</center";
		}





$conn->close();
}
else
{header("Location:search1.php? search=$_POST[search] ");}
		?>
</body>
</html>

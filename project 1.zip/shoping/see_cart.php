 <html>
	<head> <link rel="stylesheet" href="home.css">
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		  <link rel="stylesheet" href="login.css">
		  <link rel="stylesheet" href="see_cart.css">
   		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
		 
		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
	</head>
		<body>
<?php
session_start();
?>
		<form method="post" action="search.php">
			<div id="header"><h1 id="h1">DigiCart</h1><input type="text" name='search' id="search" placeholder="Search For Products"><button type="submit" id="btn"><i id="search1" class="fas fa-search"></i></button>
			<ol>
				
				<li class="ol"><div class="dropdown">
  <button class="dropbtn" id="more"><a href="#">More</a></button>
  <div class="dropdown-content">
    <a href="see_orders.php">orders</a>
  </div>
</div>
				
				<li class="ol"><a href="logout.php">Logout</a> 
			
			</ol>
			</div>
			<ul class="stick">
				<li><div class="dropdown">
  <button class="dropbtn">Mobile</button>
  <div class="dropdown-content">
    <a href="realme.php">Realme</a>
    <a href="samsang.php">Samsang</a>
    <a href="redmi.php">Redmi</a>
	<a href="search1.php?search=poco">Poco</a>
    <a href="search1.php?search=vivo">Vivo</a>
    <a href="search1.php?search=asus">Asus</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Television</button>
  <div class="dropdown-content">
    <a href="#">Brand 1</a>
    <a href="#">Brand 2</a>
    <a href="#">Brand 3</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Laptop</button>
  <div class="dropdown-content">
    <a href="#">Brand 1</a>
    <a href="#">Brand 2</a>
    <a href="#">Brand 3</a>
  </div>
</div>
				
			</ul>
		</form>
<label for="show" class="show-btn"><i class="fas fa-user"></i><?php echo "  ".$_SESSION["user"]; ?></label>
<a href="home.php">back</a>

	<?php

if(isset($_SESSION["uname"])){
			$servername="localhost";
			$username = "root";
			$passwoard ="";
			$dbname="reg";
			$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			//echo "connected";
			$username="";
			$username= $_SESSION["email"]; 
			$sql="SELECT * FROM cart WHERE email='$username'";
			$total="SELECT SUM(price) as `ttl` FROM cart WHERE email='$username'";
			$result= $conn->query($sql);
			$tresult= $conn->query($total);
			$sum=mysqli_fetch_array($tresult);
			if($result->num_rows>0){
				
				?>
				<center><table border=1 width="50%" style='border-collapse: collapse' id="customers">
				
				<tr>
				<th>Brand
				<th>Model
				<th>Price
				<th>Remove
				</tr>	
				<?php
					while($rows = $result->fetch_assoc()) {?>
						
	<tr>
	
								<td><?php echo $rows["brand"]; ?></td>
								<td><?php echo $rows["model"]; ?></td>
								<td><?php echo $rows["price"]; ?></td>
								<td><?php echo"<a href='remove.php?serial=$rows[serial]'>" ?><button id="remove" type="button">Remove</button></a>
	
	
	
						  			<?php	}
						echo"</table>";
					echo "Total Cart Amount : ". $sum['ttl'];
						echo "</center>";}
			else{ echo"<center>"."<h2>"."NO product in your cart"."</h2>"."</center";
				}
			





$conn->close();
}
else
{echo "<script>
alert('Login To See Cart');
window.location.href='index.php';
</script>";}
		?>
</body>
</html>

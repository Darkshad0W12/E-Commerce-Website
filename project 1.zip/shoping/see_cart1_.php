 <html>
	<head> <link rel="stylesheet" href="home.css">
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		  <link rel="stylesheet" href="login.css">
		  <link rel="stylesheet" href="see_cart.css">
   		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
	</head>
		<body>
<?php
session_start();
?>
		<form method="post" action="search.php">
			<div id="header"><h1 id="h1">Y-mart</h1><input type="text" name='search' id="search" placeholder="Search For Products"><button type="submit" id="btn"><i id="search1" class="fas fa-search"></i></button>
			<ol>
				
				<li class="ol"><div class="dropdown">
  <button class="dropbtn" id="more"><a href="#">More</a></button>
  <div class="dropdown-content">
    <a href="see_orders.php">orders</a>
  </div>
</div>
				
				<li class="ol"><a href="logout.php">Logout</a> 
			
			</ol>
			</div>
			<ul class="stick">
				<li><div class="dropdown">
  <button class="dropbtn">Mobile</button>
  <div class="dropdown-content">
    <a href="realme.php">Realme</a>
    <a href="samsang.php">Samsang</a>
    <a href="redmi.php">Redmi</a>
	<a href="search1.php?search=poco">Poco</a>
    <a href="search1.php?search=vivo">Vivo</a>
    <a href="search1.php?search=asus">Asus</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Television</button>
  <div class="dropdown-content">
    <a href="#">Brand 1</a>
    <a href="#">Brand 2</a>
    <a href="#">Brand 3</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Laptop</button>
  <div class="dropdown-content">
    <a href="#">Brand 1</a>
    <a href="#">Brand 2</a>
    <a href="#">Brand 3</a>
  </div>
</div>
				
			</ul>
		</form>
<label for="show" class="show-btn"><i class="fas fa-user"></i><?php echo "  ".$_SESSION["user"]; ?></label>
<a href="home.php">back</a>

	<?php

if(isset($_SESSION["uname"])){
			$servername="localhost";
			$username = "root";
			$passwoard ="";
			$dbname="reg";
			$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			//echo "connected";
			$username="";
			$username= $_SESSION["email"]; 
			$sql="SELECT * FROM cart WHERE email='$username'";
			$total="SELECT SUM(price) as `ttl` FROM cart WHERE email='$username'";
			$result= $conn->query($sql);
			$tresult= $conn->query($total);
			$sum=mysqli_fetch_array($tresult);
			if($result->num_rows>0){
				$st=0;
				echo"<center>". "<table border =\"1\" style='border-collapse: collapse' width = 50%>";
	for ($row=1; $row <=1 ; $row++) { 
		echo "<tr> \n";
		$p="";
		
		for ($col=1; $col <= 4; $col++) { 
		   if($col==1 && $row == 1){
			   $p="Brand ";
		   }
		   else if($col==2 && $row == 1){
			    $p="Model";
			   
		   }
		    else if($col==3 && $row == 1){
			    $p="serial";
			   
		   }
		    else if($row == 1 && $col==4){
			    $p="Price";
			   
		   }
		   
		   echo '<td width=10%>'.'<center><b>'.$p.'</b></center>'.'</td>   ';
		   
		   	}
	  	    echo "</tr>";
			
		//$st=1;
		}
		echo"<center>". "</table>";
			
			
					while($rows = $result->fetch_assoc()) {
						$st=1;
						//$rows = $result->fetch_assoc();
						//$rows = $result->fetch_assoc();

echo"<center>". "<table border =\"1\" style='border-collapse: collapse' width = 50%>";
	for ($row=1; $row <=$st ; $row++) { 
		echo "<tr> \n";
		$p="";
		
		for ($col=1; $col <= 4; $col++) { 
		   if($col==1 && $row == 1){
			  $p=$rows["brand"];
		   }
		   else if($col==2 && $row == 1){
			    $p=$rows["model"];
			   
		   }
		    else if($col==3 && $row == 1){
			    $p=$rows["serial"];
			   
		   }
		    else if($row == 1 && $col==4){
			   $p=$rows["price"];
			   
		   }
		   
		   echo '<td width=10%>'.$p.'</td>';
		   
		   	}
	  	    echo "</tr>";
			
		//$st=1;
		}
		echo"<center>". "</table>";
		
		

								//header("Location:index.html");
						  				}
		
					echo "Total Cart Amount : ". $sum['ttl'];
					echo "</tr>"."</table>";

						}
			else{ echo"<center>"."<h2>"."NO product in your cart"."</h2>"."</center";
				}
			





$conn->close();
}
else
{echo "<script>
alert('Login To See Cart');
window.location.href='index.php';
</script>";}
		?>
</body>
</html>

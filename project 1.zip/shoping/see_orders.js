  var val;
 
 window.addEventListener("contextmenu",function(event){
 event.preventDefault();
  <!-- alert( event.offsetY ); alert(event.offsetX); -->
   var cnm = document.getElementById("pos");
   
  var x=event.clientX;
  var y=event.clientY;
 cnm.style.left = x+"px";
 cnm.style.top = y+"px";
 cnm.style.display = "block";
 cnm.classList.add("active");
 val = document.getElementById("hidden").value;
 if(val==""){
	 alert("select a product");
	  cnm.style.display = "none";
 }else{
	 //alert(val);
 }
 
 console.log(x,y);
});

window.addEventListener("click",function(){
	var cnm = document.getElementById("pos");
	cnm.classList.remove("active");
	
});
function req(){
	// alert("Your Order id is:-"+val);
	// alert(document.cookie);
	window.location.replace("see_orders.php?req="+val); 
};
 <html>
	<head> <link rel="stylesheet" href="home.css">
<title>Orders</title>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" 
rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
<link rel="stylesheet" href="bill.css">
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		  <link rel="stylesheet" href="login.css">
   		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
		 <script src="see_orders.js"></script>
		 <link rel="stylesheet" href="see_orders.css">
		
	  <style>
	  #pos{
			background:#222;
			width:200px;
			position:fixed;
			top:0px;
			left:0px;
			z-index:10000;
			transform: scale(0);
			transform-origin:top left;
	  }
	  #pos.active{
		  transform: scale(1);
		  transition:transform 200ms ease-in-out;
	  }
	  #pos .item{
		  color:#fff;
		  padding:5px;
	  }
	  #pos .item:hover{
		  background:#555;
	  }

	  
	  </style>
		 <script>function ids(id){
	 document.getElementById("hidden").value=id;
	 document.getElementById(id).checked = true;
	 document.getElementById(id).style.display = "block";
	//alert(id);
};
</script>
		 
	</head>
		<body>
		 
<?php
session_start();
if(isset($_GET["req"])){
	$oid=$_GET["req"];
	// echo "got it";
	$body="ok";
	$to_email ="somnathnath8482@gmail.com";
	$subject= "Request for chenge Delivery date";
	$body="please can you delay my delivery? for the orderid-".$oid;
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	
	 // mail($to_email,$subject,$body);
	 // header("Location: mailto: confarenceteam@gmail.com");
	// echo "<a href='mailto:somnathnath8482@gmil.com'>ok</a>";
	if (mail($to_email, $subject, $body)) {
	unset($_GET["req"]);
	 header("Location: " . $_SERVER["HTTP_REFERER"]);

						} 
else {
    // echo "Email sending failed...";
	header("Location: mailto: confarenceteam@gmail.com");
	}

	
	
}

?>

      <div id="pos" >
			 <div class="item" onclick="req()">
			   Request For Delay Delivery</div> 
      </div>

		<input type="hidden" id="hidden" value="">

	<?php

if(isset($_SESSION["uname"])){
			$servername="localhost";
			$username = "root";
			$passwoard ="";
			$dbname="reg";
			$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			//echo "connected";
			$username="";
			$username= $_SESSION["email"]; 
			$sql="SELECT * FROM orders WHERE email='$username'";
			$total="SELECT SUM(price) as `ttl` FROM orders WHERE email='$username'";
			$result= $conn->query($sql);
			$tresult= $conn->query($total);
			$sum=mysqli_fetch_array($tresult);
			if($result->num_rows>0){
				$st=0;
				?>
			<center>
			<table class='table table-stripted' width="100%">
			<tr id="head">
			<th>Model
			<th>Price
			<th>Tranjaction Id
			<th>Status
			<th>Time
			<th>Expected Date
			<th colspan="3">QRcode
		</tr>
		
			<?php 
					while($rows = $result->fetch_assoc()) {
						$st=1;
						$model=$rows["model"];
						$price=$rows["price"];
						$id=$rows["id"];
						$serial=$rows["serial"];
						$status=$rows["delivery"];
						$time=$rows["time"];
						$qr=$rows["model"];
						$pid=$rows['pid'];
						$expected_date =$rows["expected"];
						 $link="bill.php?id=$serial";
						 $link1="phone/".$rows["model"]."/index.php?serial=".$rows["pid"];
							require_once'phpqrcode/phpqrcode.php';
			$path = "QR/";
			$file = $path.uniqid().".png";
				$text = 'Product name :'.$rows["model"]."\n Price : ".$rows["price"]." \n Purchase Date : ". $rows["time"]." \n Vendor  : DigiCart \n Shipping address : "
				.$_SESSION["address"]."\n Tranjaction status : ".$rows["id"];
			 QRcode::png($text,$file); 
			 //$date = $rows["date"];
			
			//$expected_date = date('Y-m-d', strtotime($time .' +5 day'));
			 
			 
			 ?>
						<?php echo "<tr onclick= ids($serial)>"?>
						<th><?php echo"<input type='radio' id= '$serial' name='vehicle1' value='Bike' style= 'display:none;' "?> <?php 
								echo "<a href='$link1'>$model</a>";?>
								
						<th><?php echo $price?>
						<th><?php echo"<a href=$link>".$id."</a>"?>
						<th><?php echo $status;
								if($rows["delivery"]=="Deliverd"){
									echo "<br>";
									echo "<a href='rating.php?pid=$pid'>rate Us</a>";
									
								}
						?>
						
						<th><?php echo $time?>
						<th><?php echo $expected_date?>
						
						<th><center><?php  echo "<td><img src='$file' width=100></td>"; ?></center></th>
									
										
										
										<?php }
					//echo "Total Orderd Amount : ". $sum['ttl'];
					echo "</tr></table> ";
					

						}
			else{ echo"<center>"."<h2>"."NO product in your Orderd list"."</h2>"."</center";
				}
			





$conn->close();
}
else
{echo "<script>
alert('Login To See Orders');
window.location.href='index.php';
</script>";}
//include("rating.php");
		?>

</body>
</html>

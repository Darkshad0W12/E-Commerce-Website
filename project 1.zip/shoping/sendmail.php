<?php 
header("Location: mailto: confarenceteam@gmail.com");

?>
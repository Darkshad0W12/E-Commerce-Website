<html>
	<head> <link rel="stylesheet" href="home.css">
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		  <link rel="stylesheet" href="login.css">
   		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
		 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
	</head>
		<body>
<?php
session_start();
?>
		<form method="post" action="search.php">
			<div id="header"><h1 id="h1">DigiTech</h1><input type="text" name='search' id="search" placeholder="Search For Products"><button type="submit" id="btn"><i id="search1" class="fas fa-search"></i></button>
			<ol>
				
				<li class="ol"><div class="dropdown">
  				<button class="dropbtn" id="more"><a href="#">More</a></button>
  				<div class="dropdown-content">
    				<a href="see_orders.php">orders</a>
 				 </div>
				</div>


				<li class="ol"><a href="see_cart.php"><i class="fas fa-cart-plus"></i>Cart</a>
			
			</ol>
			</div>
			<ul class="stick">
				<li><div class="dropdown">
  <button class="dropbtn">Mobile</button>
  <div class="dropdown-content">
    <a href="realme.php">Realme</a>
    <a href="samsang.php">Samsang</a>
    <a href="redmi.php">Redmi</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Television</button>
  <div class="dropdown-content">
    <a href="#">Sony</a>
    <a href="#">Reliance</a>
    <a href="#">Panasonic</a>
  </div>
</div>
				<li><div class="dropdown">
  <button class="dropbtn">Laptop</button>
  <div class="dropdown-content">
    <a href="#">Acer</a>
    <a href="#">Lenovo</a>
    <a href="#">Dell</a>
  </div>
</div>
				
			</ul>
		</form>
 <div class="center">
      <input type="checkbox" id="show">
      <label for="show" class="show-btn">Login</label>
      <div class="container">
        <label for="show" class="close-btn fas fa-times" title="close"></label>
        <div class="text">
DigiTech</div>
<form method="post" action="login.php">
          <div class="data">
            <label>Email or Phone</label>
            <input type="text" name="username" required>
          </div>
<div class="data">
            <label>Password</label>
            <input type="password" name="passwoard" required>
          </div>
<div class="forgot-pass">
<a href="f_password.html">Forgot Password?</a></div>
<div class="btn">
            <div class="inner">
</div>
<button type="submit">login</button>
          </div>
<div class="signup-link">
Not a member? <a href="insert.html">Signup now</a></div>
</form>
</div>
</div>
<a href="index.php">back</a>
		
		
		<table  border='0' cellspacing='10'>
  <thead>
    <tr>
      <th scope="col"># </th>
      <th scope="col">Product</th>
      <th scope="col">Price</th>
      <th scope="col">Tranjaction-Id</th>
      <th scope="col">Date/Time</th>
    </tr>
  </thead>
  <tbody>
  <?php
			$servername="localhost";
			$username = "root";
			$passwoard ="";
			$dbname="reg";
			$conn=mysqli_connect($servername,$username,$passwoard,$dbname);
			if(!$conn){die("connection error : " .mysquli_connect_error());
				}
			//echo "connected";
			$username="";
			$username="";
			$sql="SELECT * FROM mobile WHERE model like '$username%' OR brand like '$username%' OR storage like '%$username%' OR price <='$username' OR details like '%$username%'";
			$result= $conn->query($sql);
			$total = mysql_num_rows($result);
			if($result->num_rows>0){
				$num=0;
				$all;
					while($row = mysqli_fetch_array($result)){
						$num++;	
						$image=$row["pic"];
						$link='phone/'.$row["model"].'?serial='.$row["serial"];
						//$all=array($image, $link, $row["brand"], $row["model"], $row["price"],$row["storage"]);
						
						?>
						<tr>
      <th scope="row">1</th>
      <td><?php echo $row["pic"]?></td>
      <td><?php echo $row["price"]?></td>
      <td><?php echo $row["model"]?></td>
      <td><?php echo $total?></td>
    </tr>
    			
											  <?php
						 }		
						}
	else{ echo"<center>"."<h2>"." The product you are looking for is not available right now"."</h2>"."</center";
		}
$conn->close();
		?>
  </tbody>
</table>
</body>
</html>
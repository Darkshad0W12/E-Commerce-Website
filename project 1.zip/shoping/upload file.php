<?php
  $msg = "";
session_start();  // If upload button is clicked ...
 $uname= $_SESSION["uname"];
 //$upload =$_POST['upload'];
 $upload = (isset($_POST['upload'])?$_POST['upload']:"no");
 if($upload != "no")	{
 
    $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];   
        $folder = "image/".$filename;
         require_once'conn.php';
  
        // Get all the submitted data from the form
        $sql = "INSERT INTO image (filename,username) VALUES ('$filename','$uname	')";
 
        // Execute query
        mysqli_query($conn, $sql);
         
        // Now let's move the uploaded image into the folder: image
        if (move_uploaded_file($tempname, $folder))  {
            $msg = "Image uploaded successfully";
			echo"<script> alert("Product Added");</script>";
			 $_POST['upload'] ="";
        }else{
            $msg = "Failed to upload image";
      }
 }
           require_once'conn.php';
  
  $result = mysqli_query($conn, "SELECT * FROM image");
  while($data = mysqli_fetch_array($result)){
	  $name =$data['filename'];
  }
  

 
      ?>
	  
	  <img width='20%' src="image/<?php echo $name ?> ">


 
<!DOCTYPE html>
<html>
<head>
<title>Image Upload</title>

</head>
<body>
<div id="content">
 
  <form method="POST" action="profile.php" enctype="multipart/form-data">
      <input type="file" name="uploadfile" value=""/>
       
      <div>
          <button type="submit" name="upload">UPLOAD</button>
        </div>
  </form>
</div>
</body>
</html>